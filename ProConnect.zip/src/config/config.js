module.exports = {
        "db" : {
        "user"     : "root",
        "password" : "",
        "database" : "ProConnect",
        "host"     : "127.0.0.1"
    },
        "passport" : {
            "secret"    : "mysecret"
        }
}
